# app.py
import os
import joblib
import numpy as np
import pandas as pd
from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET", "change_me_for_prod")

# Paths (update if you use different paths)
DATASET_PATH = "final_commodity_price_dataset.xlsx"
MODEL_PATH = "artifacts/best_pipeline.joblib"

# Expected features
EXPECTED_FEATURES = [
    "Commodity", "Variation", "Unit", "Avg_Price",
    "Weather", "Seasonal Harvest", "Day_of_Week"
]

# Load dataset to populate dropdowns
if not os.path.exists(DATASET_PATH):
    raise FileNotFoundError(f"Dataset not found at {DATASET_PATH}. Place your dataset there to populate dropdowns.")

df = pd.read_excel(DATASET_PATH)
# Clean and ensure columns exist
missing_cols = [c for c in EXPECTED_FEATURES if c not in df.columns and c != "Avg_Price"]
if missing_cols:
    raise KeyError(f"The dataset is missing required columns needed for dropdowns: {missing_cols}")

# If Avg_Price not present, derive from Max/Min if available - dropdowns don't need Avg_Price
if "Avg_Price" not in df.columns:
    if "Max Price" in df.columns and "Min Price" in df.columns:
        df["Avg_Price"] = df[["Max Price", "Min Price"]].mean(axis=1)
    else:
        df["Avg_Price"] = np.nan

# Helper to extract sorted unique values and convert to str (and fillna)
def get_options(col):
    if col not in df.columns:
        return []
    vals = df[col].dropna().unique().astype(str)
    vals = sorted(vals, key=lambda x: x.lower())
    return vals

# Dropdown options
OPTIONS = {
    "Commodity": get_options("Commodity"),
    "Variation": get_options("Variation"),
    "Unit": get_options("Unit"),
    "Weather": get_options("Weather"),
    "Seasonal Harvest": get_options("Seasonal Harvest"),
    "Day_of_Week": get_options("Day_of_Week")
}

# Load pipeline
if not os.path.exists(MODEL_PATH):
    print(f"Warning: model not found at {MODEL_PATH}. Start the server after placing the trained pipeline.")
    pipeline = None
else:
    pipeline = joblib.load(MODEL_PATH)
    print("Loaded pipeline from", MODEL_PATH)

def compute_confidence(pipeline, X_df):
    """
    Return a float confidence in [0,1] if possible.
    If predict_proba available -> return probability for class 1.
    Else if decision_function available -> convert via sigmoid to pseudo-probability.
    Else -> return None.
    """
    clf = pipeline.named_steps.get('clf') if pipeline is not None else None
    try:
        if hasattr(pipeline, "predict_proba"):
            proba = pipeline.predict_proba(X_df)[0]
            # if binary, proba[1] is class 1
            if len(proba) == 2:
                return float(proba[1])
            else:
                # fallback: max probability
                return float(np.max(proba))
        elif clf is not None and hasattr(clf, "predict_proba"):
            proba = clf.predict_proba(pipeline.named_steps['pre'].transform(X_df))[0]
            return float(proba[1]) if len(proba) == 2 else float(np.max(proba))
        elif hasattr(pipeline, "decision_function"):
            score = float(pipeline.decision_function(X_df)[0])
            # sigmoid to map to (0,1)
            return float(1 / (1 + np.exp(-score)))
        elif clf is not None and hasattr(clf, "decision_function"):
            score = float(clf.decision_function(pipeline.named_steps['pre'].transform(X_df))[0])
            return float(1 / (1 + np.exp(-score)))
    except Exception:
        return None
    return None

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", options=OPTIONS)

@app.route("/result", methods=["POST"])
def result():
    # Read form
    form = request.form
    # validate required fields
    missing = [f for f in EXPECTED_FEATURES if f not in form or form.get(f, "").strip() == ""]
    if missing:
        flash(f"Please fill all fields. Missing: {missing}", "warning")
        return redirect(url_for("index"))

    # Build a one-row DataFrame for prediction
    try:
        row = {}
        for f in EXPECTED_FEATURES:
            val = form.get(f)
            if f == "Avg_Price":
                val = val.replace(",", "").strip()
                price = float(val)
                row[f] = price
            else:
                row[f] = str(val)
        X_df = pd.DataFrame([row], columns=EXPECTED_FEATURES)
    except Exception as e:
        flash("Invalid input for Avg_Price. Must be numeric.", "danger")
        return redirect(url_for("index"))

    if pipeline is None:
        flash("Model not loaded on server. Please place trained pipeline at artifacts/best_pipeline.joblib", "danger")
        return redirect(url_for("index"))

    # Predict
    try:
        pred = pipeline.predict(X_df)[0]
        confidence = compute_confidence(pipeline, X_df)
    except Exception as e:
        flash(f"Prediction error: {e}", "danger")
        return redirect(url_for("index"))

    # Interpret result for UI
    if int(pred) == 1:
        status = "Syndicate can be present"
        color = "danger"   # red
    else:
        status = "Syndicate symptom not found"
        color = "success"  # green

    # format confidence
    conf_display = None
    if confidence is not None:
        conf_display = f"{confidence*100:.2f}%"
    else:
        conf_display = "N/A"

    return render_template("result.html",
                           status=status,
                           color=color,
                           confidence=conf_display,
                           inputs=row)

if __name__ == "__main__":
    # dev server; for production use gunicorn/uvicorn + reverse proxy
    app.run(host="0.0.0.0", port=5000, debug=True)
